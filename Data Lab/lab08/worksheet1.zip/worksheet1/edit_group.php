<?php require_once('connect.php'); ?> 
<?php
if (isset($_POST['submit']))
{
	$v1 = $_POST['groupcode'];
	 $v2 = $_POST['groupname'];
	 $v3 = $_POST['remark'];
	 $v4 = $_POST['url'];
	 
	 $vid = $_POST['groupid'];
	 
	$q = "UPDATE USERGROUP SET " .
	" USERGROUP_CODE = '".$v1."' , " .
		" USERGROUP_NAME = '".$v2."' , " .
			" USERGROUP_REMARK = '".$v3."'  , " .
			" USERGROUP_URL = '".$v4."'  " .
			" WHERE USERGROUP_ID = '".$vid."'  ";
			
			$result=$mysqli->query($q);
					if($result){
					header("Location: group.php");
					}
					
					
}
else if (isset($_GET['id']))
{
				 	$q="select * from USERGROUP WHERE USERGROUP_ID = " . $_GET['id'];
					$result=$mysqli->query($q);
					if(!$result){
						echo "Select failed. Error: ".$mysqli->error ;
						break;
					}
				 if ($row=$result->fetch_array()){
					 $vid = $row['USERGROUP_ID'];
					 $v1 = $row['USERGROUP_CODE'];
					 $v2 = $row['USERGROUP_NAME'];
					 $v3 = $row['USERGROUP_REMARK'];
					 $v4 = $row['USERGROUP_URL'];
					 $mode = 'u';
				 }
}
?>
<!DOCTYPE html>
<html>
<head>
<title>ITS331 Sample</title>
<link rel="stylesheet" href="default.css">
</head>

<body>

<div id="wrapper"> 
	<div id="div_header">
		ITS331 System 
	</div>
	<div id="div_subhead">
		<ul id="menu">
			<li><a href="user.php">User Profile</a></li>
			<li><a href="add_user.php">Add User</a></li>
			<li><a href="group.php">User Group</a></li>
			<li><a href="add_group.html">Add User Group</a></li>
		</ul>		
	</div>
	<div id="div_main">
		<div id="div_left">
				
		</div>
		<div id="div_content" class="form">
			<!--%%%%% Main block %%%%-->
			<!--Form -->
				<h2>Add User Group</h2>
				<form action="edit_group.php" method="post">
				<input type="hidden" name="groupid" value="<?php echo $vid; ?>">
				
				<label>Group Code</label>
				<input type="text" name="groupcode" value="<?php echo $v1; ?>">
				
				<label>Group Name</label>
				<input type="text" name="groupname" value="<?php echo $v2; ?>">
				
				<label>Remark</label>
				<textarea name="remark"><?php echo $v3; ?></textarea><br>
					
				<label>URL</label>
				<input type="text" name="url" value="<?php echo $v4; ?>">
					
				<div class="center">
					<input type="submit" name="submit" value="Submit">
					<input type="reset" value="Cancel">											
				</div>
				</form>
		</div> <!-- end div_content -->
		
	</div> <!-- end div_main -->
	
	<div id="div_footer">  
		
	</div>

</div>
</body>
</html>

