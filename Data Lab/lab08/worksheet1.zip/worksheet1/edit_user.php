<?php require_once('connect.php'); ?> 
<?php
if (isset($_POST['submit']))
{
	$v1 = $_POST['firstname'];
	 $v2 = $_POST['lastname'];
	 $v3 = $_POST['email'];
	 $v4 = $_POST['username'];
	 $v5 = $_POST['passwd'];
	 
	 $vid = $_POST['userid'];
	 
	$q = "UPDATE USER SET " .
	" USER_FNAME = '".$v1."' , " .
		" USER_LNAME = '".$v2."' , " .
			" USER_EMAIL = '".$v3."'  , " .
			" USER_NAME = '".$v4."'  " .
			" WHERE USER_ID = '".$vid."'  ";
			
			$result=$mysqli->query($q);
					if($result){
					header("Location: user.php");
					}
					
					
}
else if (isset($_GET['userid']))
{
				 	$q="select * from USER,USERGROUP,TITLE,GENDER where USER.USER_GROUPID=USERGROUP.USERGROUP_ID AND USER.USER_TITLE=TITLE.TITLE_ID AND
					GENDER.GENDER_ID=USER.USER_GENDER AND USER_ID = " . $_GET['userid'];
					$result=$mysqli->query($q);
					if(!$result){
						echo "Select failed. Error: ".$mysqli->error ;
						break;
					}
				 if ($row=$result->fetch_array()){
					 $vid = $row['USER_ID'];
					 $v1 = $row['USER_FNAME'];
					 $v2 = $row['USER_LNAME'];
					 $v3 = $row['USER_EMAIL'];
					 $v4 = $row['USER_NAME'];
					 $v5 = $row['USER_PASSWD'];
					 
					 $vg = $row['USER_TITLE'];
					 $vg2 = $row['USER_GENDER'];
					 
					 $vgroup = $row['USERGROUP_ID'];
					 
					 var_dump($row);
					 
					 $mode = 'u';
				 }
}
?>
<!DOCTYPE html>
<html>
<head>
<title>ITS331 Sample</title>
<link rel="stylesheet" href="default.css">
</head>

<body>

<div id="wrapper"> 
	<div id="div_header">
		ITS331 System 
	</div>
	<div id="div_subhead">
		<ul id="menu">
			<li><a href="user.php">User Profile</a></li>
			<li><a href="add_user.php">Add User</a></li>
			<li><a href="group.php">User Group</a></li>
			<li><a href="add_group.html">Add User Group</a></li>
		</ul>		
	</div>
	<div id="div_main">
		<div id="div_left">
				
		</div>
		<div id="div_content" class="form">
			<!--%%%%% Main block %%%%-->
			<!--Form -->
			
			<form action="edit_user.php" method="post">
			<input type="hidden" name="userid" value="<?php echo $vid; ?>">
			
					<h2>User Profile</h2>
					<label>Title</label>
					<select name="title">
					<?php
						$q='select TITLE_ID, TITLE_NAME from TITLE;';
						if($result=$mysqli->query($q)){
							while($row=$result->fetch_array()){
								if ($vg == $row[0])
									echo '<option value="'.$row[0].'" SELECTED>'.$row[1].'</option>';
								else
									echo '<option value="'.$row[0].'">'.$row[1].'</option>';
							}
						}else{
							echo 'Query error: '.$mysqli->error;
						}
					?>
					</select>					
					<label>First name</label>
					<input type="text" name="firstname"  value="<?php echo $v1; ?>">
						
					<label>Last name</label>
					<input type="text" name="lastname"  value="<?php echo $v2; ?>">

					<label>Gender</label>
					<?php
						$q='select GENDER_ID, GENDER_NAME from GENDER;';
						if($result=$mysqli->query($q)){
							while($row=$result->fetch_array()){
								if ($vg2 == $row[0])
									echo '<input type="radio" name="gender" value="'.$row[0].'" CHECKED>'.$row[1];
								else
									echo '<input type="radio" name="gender" value="'.$row[0].'">'.$row[1];
							}
						}else{
							echo 'Query error: '.$mysqli->error;
						}
					?>
					<div></div>
					
					<label>Email</label>
					<input type="text" name="email"  value="<?php echo $v3; ?>">
					
					<h2> Account Profile</h2>
					<label>Username</label>
					<input type="text" name="username"  value="<?php echo $v4; ?>">
					
					<label>Password</label>
					<input type="password" name="passwd"  value="<?php echo $v5; ?>">
					
					<label>Confirmed password</label>
					<input type="password" name="cpasswd">
					
					<label>User group</label>
					<select name="usergroup">
					<?php
						$q='select USERGROUP_ID, USERGROUP_NAME from USERGROUP;';
						if($result=$mysqli->query($q)){
							while($row=$result->fetch_array()){
								if ($vgroup == $row[0])
									echo '<option value="'.$row[0].'" SELECTED>'.$row[1].'</option>';
								else
									echo '<option value="'.$row[0].'">'.$row[1].'</option>';
									
							}
						}else{
							echo 'Query error: '.$mysqli->error;
						}
					?>
					</select>				
					<label>Disabled</label>
					<input type="checkbox" name="disabled" value="1">
					<input type="hidden" name="page" value="adduser" >
					<div class="center">
						<input type="submit" name="submit" value="Submit" >			
					</div>
				</form>
		</div> <!-- end div_content -->
		
	</div> <!-- end div_main -->
	
	<div id="div_footer">  
		
	</div>

</div>
</body>
</html>


